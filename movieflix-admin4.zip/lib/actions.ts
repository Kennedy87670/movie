"use server"

import { revalidatePath } from "next/cache"

// Movie actions
export async function createMovie(formData: FormData) {
  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/movie`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${await getAuthToken()}`,
      },
      body: formData,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to create movie")
    }

    revalidatePath("/admin/movies")
    return { success: true }
  } catch (error) {
    console.error("Error creating movie:", error)
    return { success: false, error: (error as Error).message }
  }
}

export async function updateMovie(formData: FormData) {
  const id = formData.get("id") as string

  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/movie/${id}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${await getAuthToken()}`,
      },
      body: formData,
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to update movie")
    }

    revalidatePath("/admin/movies")
    return { success: true }
  } catch (error) {
    console.error("Error updating movie:", error)
    return { success: false, error: (error as Error).message }
  }
}

export async function deleteMovie(formData: FormData) {
  const id = formData.get("id") as string

  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/movie/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${await getAuthToken()}`,
      },
    })

    if (!response.ok) {
      const error = await response.json()
      throw new Error(error.message || "Failed to delete movie")
    }

    revalidatePath("/admin/movies")
    return { success: true }
  } catch (error) {
    console.error("Error deleting movie:", error)
    return { success: false, error: (error as Error).message }
  }
}

// Helper function to get auth token
async function getAuthToken() {
  // Implementation depends on how you store tokens
  // This is a placeholder - you'll need to implement token retrieval and refresh logic
  const token = localStorage.getItem("accessToken")

  // Check if token is expired and refresh if needed
  // ...

  return token
}
