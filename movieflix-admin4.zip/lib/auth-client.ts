import { jwtDecode } from "jwt-decode"

interface JwtPayload {
  sub: string
  exp: number
  roles: string[]
}

// Check if user is authenticated
export async function checkIsAuthenticated() {
  if (typeof window === "undefined") return false

  const accessToken = localStorage.getItem("accessToken")
  if (!accessToken) return false

  try {
    const decoded = jwtDecode<JwtPayload>(accessToken)

    // Check if token is expired
    const currentTime = Math.floor(Date.now() / 1000)
    if (decoded.exp < currentTime) {
      // Token is expired, try to refresh
      const refreshed = await refreshToken()
      return refreshed
    }

    return true
  } catch (error) {
    console.error("Error checking authentication:", error)
    return false
  }
}

// Check if user is admin
export async function checkIsAdmin() {
  if (typeof window === "undefined") return false

  const accessToken = localStorage.getItem("accessToken")
  if (!accessToken) return false

  try {
    const decoded = jwtDecode<JwtPayload>(accessToken)

    // Check if token is expired
    const currentTime = Math.floor(Date.now() / 1000)
    if (decoded.exp < currentTime) {
      // Token is expired, try to refresh
      const refreshed = await refreshToken()
      if (!refreshed) return false

      // Get the new token and check roles
      const newToken = localStorage.getItem("accessToken")
      if (!newToken) return false

      const newDecoded = jwtDecode<JwtPayload>(newToken)
      return newDecoded.roles.includes("ADMIN")
    }

    // Check if user has admin role
    return decoded.roles.includes("ADMIN")
  } catch (error) {
    console.error("Error checking admin role:", error)
    return false
  }
}

// Refresh the access token using refresh token
async function refreshToken() {
  const refreshToken = localStorage.getItem("refreshToken")
  if (!refreshToken) return false

  try {
    const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"
    const response = await fetch(`${API_BASE_URL}/api/v1/auth/refresh`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ refreshToken }),
    })

    if (!response.ok) return false

    const data = await response.json()
    localStorage.setItem("accessToken", data.accessToken)
    localStorage.setItem("refreshToken", data.refreshToken)
    return true
  } catch (error) {
    console.error("Error refreshing token:", error)
    return false
  }
}

// Login function
export async function login(email: string, password: string) {
  try {
    const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"
    const response = await fetch(`${API_BASE_URL}/api/v1/auth/login`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ email, password }),
    })

    if (!response.ok) {
      const errorData = await response.json()
      throw new Error(errorData.message || "Login failed")
    }

    const data = await response.json()

    // Store tokens in localStorage
    localStorage.setItem("accessToken", data.accessToken)
    localStorage.setItem("refreshToken", data.refreshToken)

    // Store user info if available
    if (data.user) {
      localStorage.setItem("user", JSON.stringify(data.user))
    }

    return true
  } catch (error) {
    console.error("Login error:", error)
    throw error
  }
}

// Logout function
export function logout() {
  if (typeof window === "undefined") return

  localStorage.removeItem("accessToken")
  localStorage.removeItem("refreshToken")
  localStorage.removeItem("user")
}
