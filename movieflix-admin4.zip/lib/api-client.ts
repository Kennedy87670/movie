// Base API URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

// Helper function to get auth token from localStorage
function getAuthToken() {
  if (typeof window === "undefined") return null
  return localStorage.getItem("accessToken")
}

// Helper function to handle API responses
async function handleResponse(response: Response) {
  if (response.ok) {
    return await response.json()
  }

  // Handle 401 Unauthorized - token might be expired
  if (response.status === 401) {
    // Try to refresh the token
    const refreshed = await refreshToken()
    if (refreshed) {
      // Retry the original request with the new token
      const retryResponse = await fetch(response.url, {
        ...response,
        headers: {
          ...response.headers,
          Authorization: `Bearer ${getAuthToken()}`,
        },
      })

      if (retryResponse.ok) {
        return await retryResponse.json()
      }
    }

    // If refresh failed or retry failed, redirect to login
    if (typeof window !== "undefined") {
      localStorage.removeItem("accessToken")
      localStorage.removeItem("refreshToken")
      window.location.href = "/login?callbackUrl=" + encodeURIComponent(window.location.pathname)
    }
  }

  // For other errors, throw with the error message
  const errorData = await response.json().catch(() => ({ message: "An unknown error occurred" }))
  throw new Error(errorData.message || `Request failed with status ${response.status}`)
}

// Refresh the access token using refresh token
async function refreshToken() {
  if (typeof window === "undefined") return false

  const refreshToken = localStorage.getItem("refreshToken")
  if (!refreshToken) return false

  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/auth/refresh`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ refreshToken }),
    })

    if (!response.ok) return false

    const data = await response.json()
    localStorage.setItem("accessToken", data.accessToken)
    localStorage.setItem("refreshToken", data.refreshToken)
    return true
  } catch (error) {
    console.error("Error refreshing token:", error)
    return false
  }
}

// Fetch dashboard statistics
export async function fetchDashboardStats() {
  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/admin/stats`, {
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
      },
    })

    return await handleResponse(response)
  } catch (error) {
    console.error("Error fetching dashboard stats:", error)
    // Return default stats if API fails
    return {
      totalMovies: 0,
      totalUsers: 0,
      newMoviesThisMonth: 0,
      newUsersThisMonth: 0,
      pageViews: 0,
      pageViewsIncrease: 0,
    }
  }
}

// Fetch movies with pagination, sorting, and search
export async function fetchMovies({
  page = 1,
  sort = "title",
  order = "asc",
  search = "",
}: {
  page?: number
  sort?: string
  order?: string
  search?: string
}) {
  try {
    const params = new URLSearchParams({
      page: (page - 1).toString(), // Spring Boot pagination is 0-based
      size: "10", // 10 items per page
      sort: `${sort},${order}`,
    })

    if (search) {
      params.append("search", search)
    }

    const response = await fetch(`${API_BASE_URL}/api/v1/movie?${params}`, {
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
      },
    })

    return await handleResponse(response)
  } catch (error) {
    console.error("Error fetching movies:", error)
    return { content: [], totalPages: 0, totalElements: 0 }
  }
}

// Fetch a single movie by ID
export async function fetchMovieById(id: string) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
      },
    })

    if (response.status === 404) {
      return null
    }

    return await handleResponse(response)
  } catch (error) {
    console.error(`Error fetching movie with ID ${id}:`, error)
    return null
  }
}

// Create a new movie
export async function createMovie(formData: FormData) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/movie`, {
      method: "POST",
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
      },
      body: formData,
    })

    return await handleResponse(response)
  } catch (error) {
    console.error("Error creating movie:", error)
    throw error
  }
}

// Update an existing movie
export async function updateMovie(id: string, formData: FormData) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
      method: "PUT",
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
      },
      body: formData,
    })

    return await handleResponse(response)
  } catch (error) {
    console.error("Error updating movie:", error)
    throw error
  }
}

// Delete a movie
export async function deleteMovie(id: string) {
  try {
    const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
      method: "DELETE",
      headers: {
        Authorization: `Bearer ${getAuthToken()}`,
      },
    })

    if (response.status === 204) {
      return true
    }

    return await handleResponse(response)
  } catch (error) {
    console.error("Error deleting movie:", error)
    throw error
  }
}
