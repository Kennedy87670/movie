import { cookies } from "next/headers"
import { jwtDecode } from "jwt-decode"

interface JwtPayload {
  sub: string
  exp: number
  roles: string[]
}

// Check if user is authenticated and has admin role
export async function checkAdminAuth() {
  const cookieStore = cookies()
  const accessToken = cookieStore.get("accessToken")?.value

  if (!accessToken) {
    return false
  }

  try {
    const decoded = jwtDecode<JwtPayload>(accessToken)

    // Check if token is expired
    const currentTime = Math.floor(Date.now() / 1000)
    if (decoded.exp < currentTime) {
      // Token is expired, try to refresh
      const refreshed = await refreshToken()
      if (!refreshed) {
        return false
      }
    }

    // Check if user has admin role
    return decoded.roles.includes("ADMIN")
  } catch (error) {
    console.error("Error decoding JWT:", error)
    return false
  }
}

// Refresh the access token using refresh token
async function refreshToken() {
  const cookieStore = cookies()
  const refreshToken = cookieStore.get("refreshToken")?.value

  if (!refreshToken) {
    return false
  }

  try {
    const response = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/auth/refresh`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({ refreshToken }),
    })

    if (!response.ok) {
      return false
    }

    const data = await response.json()

    // Update cookies with new tokens
    cookieStore.set("accessToken", data.accessToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
      maxAge: 60 * 60, // 1 hour
    })

    cookieStore.set("refreshToken", data.refreshToken, {
      httpOnly: true,
      secure: process.env.NODE_ENV === "production",
      sameSite: "strict",
      path: "/",
      maxAge: 7 * 24 * 60 * 60, // 7 days
    })

    return true
  } catch (error) {
    console.error("Error refreshing token:", error)
    return false
  }
}
