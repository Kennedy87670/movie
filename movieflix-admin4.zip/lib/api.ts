import { cookies } from "next/headers"

// Base API URL
const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

// Helper function to get auth token from cookies
async function getAuthToken() {
  const cookieStore = cookies()
  return cookieStore.get("accessToken")?.value
}

// Fetch dashboard statistics
export async function fetchDashboardStats() {
  try {
    const token = await getAuthToken()

    const response = await fetch(`${API_BASE_URL}/api/v1/admin/stats`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      next: { revalidate: 60 }, // Revalidate every minute
    })

    if (!response.ok) {
      throw new Error("Failed to fetch dashboard stats")
    }

    return await response.json()
  } catch (error) {
    console.error("Error fetching dashboard stats:", error)
    // Return default stats if API fails
    return {
      totalMovies: 0,
      totalUsers: 0,
      newMoviesThisMonth: 0,
      newUsersThisMonth: 0,
      pageViews: 0,
      pageViewsIncrease: 0,
    }
  }
}

// Fetch movies with pagination, sorting, and search
export async function fetchMovies({
  page = 1,
  sort = "title",
  order = "asc",
  search = "",
}: {
  page?: number
  sort?: string
  order?: string
  search?: string
}) {
  try {
    const token = await getAuthToken()
    const params = new URLSearchParams({
      page: page.toString(),
      size: "10", // 10 items per page
      sort: `${sort},${order}`,
      search,
    })

    const response = await fetch(`${API_BASE_URL}/api/v1/movie?${params}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      next: { revalidate: 30 }, // Revalidate every 30 seconds
    })

    if (!response.ok) {
      throw new Error("Failed to fetch movies")
    }

    const data = await response.json()

    return {
      movies: data.content,
      totalPages: data.totalPages,
      totalElements: data.totalElements,
    }
  } catch (error) {
    console.error("Error fetching movies:", error)
    return { movies: [], totalPages: 0, totalElements: 0 }
  }
}

// Fetch a single movie by ID
export async function fetchMovieById(id: string) {
  try {
    const token = await getAuthToken()

    const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
      headers: {
        Authorization: `Bearer ${token}`,
      },
      next: { revalidate: 30 }, // Revalidate every 30 seconds
    })

    if (!response.ok) {
      if (response.status === 404) {
        return null
      }
      throw new Error("Failed to fetch movie")
    }

    return await response.json()
  } catch (error) {
    console.error(`Error fetching movie with ID ${id}:`, error)
    return null
  }
}
