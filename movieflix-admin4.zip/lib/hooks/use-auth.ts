"use client"

import { useMutation, useQueryClient } from "@tanstack/react-query"
import { jwtDecode } from "jwt-decode"
import { useRouter } from "next/navigation"
import { useToast } from "@/components/ui/use-toast"

interface JwtPayload {
  sub: string
  exp: number
  roles: string[]
}

interface LoginCredentials {
  email: string
  password: string
}

interface LoginResponse {
  accessToken: string
  refreshToken: string
  user: {
    id: string
    email: string
    roles: string[]
  }
}

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

export function useAuth() {
  const router = useRouter()
  const { toast } = useToast()
  const queryClient = useQueryClient()

  // Check if user is authenticated
  const checkIsAuthenticated = async () => {
    if (typeof window === "undefined") return false

    const accessToken = localStorage.getItem("accessToken")
    if (!accessToken) return false

    try {
      const decoded = jwtDecode<JwtPayload>(accessToken)

      // Check if token is expired
      const currentTime = Math.floor(Date.now() / 1000)
      if (decoded.exp < currentTime) {
        // Token is expired, try to refresh
        const refreshed = await refreshToken()
        return refreshed
      }

      return true
    } catch (error) {
      console.error("Error checking authentication:", error)
      return false
    }
  }

  // Check if user is admin
  const checkIsAdmin = async () => {
    if (typeof window === "undefined") return false

    const accessToken = localStorage.getItem("accessToken")
    if (!accessToken) return false

    try {
      const decoded = jwtDecode<JwtPayload>(accessToken)

      // Check if token is expired
      const currentTime = Math.floor(Date.now() / 1000)
      if (decoded.exp < currentTime) {
        // Token is expired, try to refresh
        const refreshed = await refreshToken()
        if (!refreshed) return false

        // Get the new token and check roles
        const newToken = localStorage.getItem("accessToken")
        if (!newToken) return false

        const newDecoded = jwtDecode<JwtPayload>(newToken)
        return newDecoded.roles.includes("ADMIN")
      }

      // Check if user has admin role
      return decoded.roles.includes("ADMIN")
    } catch (error) {
      console.error("Error checking admin role:", error)
      return false
    }
  }

  // Refresh the access token using refresh token
  const refreshToken = async () => {
    const refreshToken = localStorage.getItem("refreshToken")
    if (!refreshToken) return false

    try {
      const response = await fetch(`${API_BASE_URL}/api/v1/auth/refresh`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ refreshToken }),
      })

      if (!response.ok) return false

      const data = await response.json()
      localStorage.setItem("accessToken", data.accessToken)
      localStorage.setItem("refreshToken", data.refreshToken)
      return true
    } catch (error) {
      console.error("Error refreshing token:", error)
      return false
    }
  }

  // Login mutation
  const loginMutation = useMutation({
    mutationFn: async (credentials: LoginCredentials) => {
      const response = await fetch(`${API_BASE_URL}/api/v1/auth/login`, {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(credentials),
      })

      if (!response.ok) {
        const errorData = await response.json()
        throw new Error(errorData.message || "Login failed")
      }

      return (await response.json()) as LoginResponse
    },
    onSuccess: (data) => {
      // Store tokens in localStorage
      localStorage.setItem("accessToken", data.accessToken)
      localStorage.setItem("refreshToken", data.refreshToken)

      // Store user info if available
      if (data.user) {
        localStorage.setItem("user", JSON.stringify(data.user))
      }

      // Invalidate queries that might depend on auth state
      queryClient.invalidateQueries()
    },
  })

  // Logout function
  const logout = () => {
    if (typeof window === "undefined") return

    localStorage.removeItem("accessToken")
    localStorage.removeItem("refreshToken")
    localStorage.removeItem("user")

    // Invalidate queries that might depend on auth state
    queryClient.invalidateQueries()

    // Redirect to login
    router.push("/login")
  }

  return {
    checkIsAuthenticated,
    checkIsAdmin,
    login: loginMutation.mutate,
    isLoggingIn: loginMutation.isPending,
    logout,
  }
}
