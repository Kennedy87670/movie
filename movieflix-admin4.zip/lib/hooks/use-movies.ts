"use client"

import { useQuery, useMutation, useQueryClient } from "@tanstack/react-query"
import { useToast } from "@/components/ui/use-toast"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

// Helper function to get auth token from localStorage
function getAuthToken() {
  if (typeof window === "undefined") return null
  return localStorage.getItem("accessToken")
}

// Helper function to handle API responses
async function handleResponse(response: Response) {
  if (response.ok) {
    return await response.json()
  }

  // For errors, throw with the error message
  const errorData = await response.json().catch(() => ({ message: "An unknown error occurred" }))
  throw new Error(errorData.message || `Request failed with status ${response.status}`)
}

interface Movie {
  id: string
  title: string
  director: string
  studio: string
  cast: string
  releaseYear: number
  description: string
  posterUrl?: string
}

interface MovieListResponse {
  content: Movie[]
  totalPages: number
  totalElements: number
}

interface MovieQueryParams {
  page?: number
  sort?: string
  order?: string
  search?: string
}

// Hook for fetching movies list
export function useMovies(params: MovieQueryParams = {}) {
  const { page = 1, sort = "title", order = "asc", search = "" } = params

  return useQuery({
    queryKey: ["movies", page, sort, order, search],
    queryFn: async () => {
      const queryParams = new URLSearchParams({
        page: (page - 1).toString(), // Spring Boot pagination is 0-based
        size: "10", // 10 items per page
        sort: `${sort},${order}`,
      })

      if (search) {
        queryParams.append("search", search)
      }

      const response = await fetch(`${API_BASE_URL}/api/v1/movie?${queryParams}`, {
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
      })

      return handleResponse(response) as Promise<MovieListResponse>
    },
  })
}

// Hook for fetching a single movie
export function useMovie(id: string) {
  return useQuery({
    queryKey: ["movie", id],
    queryFn: async () => {
      const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
      })

      if (response.status === 404) {
        return null
      }

      return handleResponse(response) as Promise<Movie>
    },
  })
}

// Hook for creating a movie
export function useCreateMovie() {
  const queryClient = useQueryClient()
  const { toast } = useToast()

  return useMutation({
    mutationFn: async (formData: FormData) => {
      const response = await fetch(`${API_BASE_URL}/api/v1/movie`, {
        method: "POST",
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
        body: formData,
      })

      return handleResponse(response) as Promise<Movie>
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Movie created successfully",
      })
      queryClient.invalidateQueries({ queryKey: ["movies"] })
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to create movie",
        variant: "destructive",
      })
    },
  })
}

// Hook for updating a movie
export function useUpdateMovie() {
  const queryClient = useQueryClient()
  const { toast } = useToast()

  return useMutation({
    mutationFn: async ({ id, formData }: { id: string; formData: FormData }) => {
      const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
        method: "PUT",
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
        body: formData,
      })

      return handleResponse(response) as Promise<Movie>
    },
    onSuccess: (_, variables) => {
      toast({
        title: "Success",
        description: "Movie updated successfully",
      })
      queryClient.invalidateQueries({ queryKey: ["movies"] })
      queryClient.invalidateQueries({ queryKey: ["movie", variables.id] })
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to update movie",
        variant: "destructive",
      })
    },
  })
}

// Hook for deleting a movie
export function useDeleteMovie() {
  const queryClient = useQueryClient()
  const { toast } = useToast()

  return useMutation({
    mutationFn: async (id: string) => {
      const response = await fetch(`${API_BASE_URL}/api/v1/movie/${id}`, {
        method: "DELETE",
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
      })

      if (response.status === 204) {
        return true
      }

      return handleResponse(response)
    },
    onSuccess: () => {
      toast({
        title: "Success",
        description: "Movie deleted successfully",
      })
      queryClient.invalidateQueries({ queryKey: ["movies"] })
    },
    onError: (error) => {
      toast({
        title: "Error",
        description: error.message || "Failed to delete movie",
        variant: "destructive",
      })
    },
  })
}
