"use client"

import { useQuery } from "@tanstack/react-query"

const API_BASE_URL = process.env.NEXT_PUBLIC_API_URL || "http://localhost:8080"

// Helper function to get auth token from localStorage
function getAuthToken() {
  if (typeof window === "undefined") return null
  return localStorage.getItem("accessToken")
}

interface DashboardStats {
  totalMovies: number
  totalUsers: number
  newMoviesThisMonth: number
  newUsersThisMonth: number
  pageViews: number
  pageViewsIncrease: number
}

export function useDashboardStats() {
  return useQuery({
    queryKey: ["dashboardStats"],
    queryFn: async () => {
      const response = await fetch(`${API_BASE_URL}/api/v1/admin/stats`, {
        headers: {
          Authorization: `Bearer ${getAuthToken()}`,
        },
      })

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({ message: "An unknown error occurred" }))
        throw new Error(errorData.message || `Request failed with status ${response.status}`)
      }

      return (await response.json()) as DashboardStats
    },
    placeholderData: {
      totalMovies: 0,
      totalUsers: 0,
      newMoviesThisMonth: 0,
      newUsersThisMonth: 0,
      pageViews: 0,
      pageViewsIncrease: 0,
    },
  })
}
