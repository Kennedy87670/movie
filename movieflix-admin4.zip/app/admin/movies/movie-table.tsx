"use client"

import type React from "react"

import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Edit, Search, Trash2 } from "lucide-react"
import Image from "next/image"
import Link from "next/link"
import { useState } from "react"
import { useRouter } from "next/navigation"
import { useDeleteMovie } from "@/lib/hooks/use-movies"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import { Skeleton } from "@/components/ui/skeleton"

interface Movie {
  id: string
  title: string
  director: string
  releaseYear: number
  posterUrl?: string
}

interface MovieTableProps {
  movies: Movie[]
  sort: string
  order: string
  search: string
  isLoading: boolean
}

export function MovieTable({ movies, sort, order, search, isLoading }: MovieTableProps) {
  const router = useRouter()
  const [searchTerm, setSearchTerm] = useState(search)
  const [movieToDelete, setMovieToDelete] = useState<string | null>(null)

  const deleteMovieMutation = useDeleteMovie()

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()
    router.push(`/admin/movies?search=${searchTerm}`)
  }

  const handleSort = (column: string) => {
    const newOrder = sort === column && order === "asc" ? "desc" : "asc"
    router.push(`/admin/movies?sort=${column}&order=${newOrder}&search=${search}`)
  }

  const getSortIcon = (column: string) => {
    if (sort !== column) return null
    return order === "asc" ? "↑" : "↓"
  }

  const handleDelete = async () => {
    if (!movieToDelete) return
    deleteMovieMutation.mutate(movieToDelete, {
      onSuccess: () => {
        setMovieToDelete(null)
      },
    })
  }

  return (
    <div>
      <div className="p-4 flex items-center">
        <form onSubmit={handleSearch} className="relative flex-1">
          <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
          <Input
            type="search"
            placeholder="Search movies..."
            className="pl-8 w-full md:max-w-sm"
            value={searchTerm}
            onChange={(e) => setSearchTerm(e.target.value)}
          />
        </form>
      </div>

      <Table>
        <TableHeader>
          <TableRow>
            <TableHead className="w-[100px]">Poster</TableHead>
            <TableHead className="cursor-pointer" onClick={() => handleSort("title")}>
              Title {getSortIcon("title")}
            </TableHead>
            <TableHead className="cursor-pointer" onClick={() => handleSort("director")}>
              Director {getSortIcon("director")}
            </TableHead>
            <TableHead className="cursor-pointer" onClick={() => handleSort("releaseYear")}>
              Year {getSortIcon("releaseYear")}
            </TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {isLoading ? (
            // Loading skeletons
            Array.from({ length: 5 }).map((_, index) => (
              <TableRow key={`skeleton-${index}`}>
                <TableCell>
                  <Skeleton className="h-14 w-10" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-[250px]" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-[180px]" />
                </TableCell>
                <TableCell>
                  <Skeleton className="h-4 w-[60px]" />
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">
                    <Skeleton className="h-8 w-8" />
                    <Skeleton className="h-8 w-8" />
                  </div>
                </TableCell>
              </TableRow>
            ))
          ) : (
            <>
              {movies.map((movie) => (
                <TableRow key={movie.id}>
                  <TableCell>
                    <div className="relative h-14 w-10 overflow-hidden rounded">
                      <Image
                        src={movie.posterUrl || "/placeholder.svg?height=140&width=100"}
                        alt={movie.title}
                        fill
                        className="object-cover"
                      />
                    </div>
                  </TableCell>
                  <TableCell className="font-medium">{movie.title}</TableCell>
                  <TableCell>{movie.director}</TableCell>
                  <TableCell>{movie.releaseYear}</TableCell>
                  <TableCell className="text-right">
                    <div className="flex justify-end gap-2">
                      <Button variant="ghost" size="icon" asChild>
                        <Link href={`/admin/movies/${movie.id}/edit`}>
                          <Edit className="h-4 w-4" />
                          <span className="sr-only">Edit</span>
                        </Link>
                      </Button>
                      <AlertDialog>
                        <AlertDialogTrigger asChild>
                          <Button variant="ghost" size="icon" onClick={() => setMovieToDelete(movie.id)}>
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </AlertDialogTrigger>
                        <AlertDialogContent>
                          <AlertDialogHeader>
                            <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                            <AlertDialogDescription>
                              This will permanently delete the movie &quot;{movie.title}&quot;. This action cannot be
                              undone.
                            </AlertDialogDescription>
                          </AlertDialogHeader>
                          <AlertDialogFooter>
                            <AlertDialogCancel>Cancel</AlertDialogCancel>
                            <AlertDialogAction onClick={handleDelete} disabled={deleteMovieMutation.isPending}>
                              {deleteMovieMutation.isPending && movieToDelete === movie.id ? "Deleting..." : "Delete"}
                            </AlertDialogAction>
                          </AlertDialogFooter>
                        </AlertDialogContent>
                      </AlertDialog>
                    </div>
                  </TableCell>
                </TableRow>
              ))}

              {movies.length === 0 && !isLoading && (
                <TableRow>
                  <TableCell colSpan={5} className="text-center py-8 text-muted-foreground">
                    No movies found. Try a different search or add a new movie.
                  </TableCell>
                </TableRow>
              )}
            </>
          )}
        </TableBody>
      </Table>
    </div>
  )
}
