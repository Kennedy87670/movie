"use client"

import { Button } from "@/components/ui/button"
import { Card } from "@/components/ui/card"
import { Plus } from "lucide-react"
import Link from "next/link"
import { MovieTable } from "./movie-table"
import { MoviePagination } from "./movie-pagination"
import { useSearchParams } from "next/navigation"
import { useMovies } from "@/lib/hooks/use-movies"

export default function MoviesPage() {
  const searchParams = useSearchParams()
  const page = Number(searchParams.get("page") || "1")
  const sort = searchParams.get("sort") || "title"
  const order = searchParams.get("order") || "asc"
  const search = searchParams.get("search") || ""

  const { data, isLoading, error } = useMovies({ page, sort, order, search })

  return (
    <div>
      <div className="flex justify-between items-center mb-6">
        <h1 className="text-3xl font-bold">Movies</h1>
        <Button asChild>
          <Link href="/admin/movies/new">
            <Plus className="mr-2 h-4 w-4" />
            Add Movie
          </Link>
        </Button>
      </div>

      {error && (
        <div className="p-4 mb-4 bg-red-50 text-red-500 rounded-md">
          Error loading movies: {(error as Error).message}
        </div>
      )}

      <Card>
        <MovieTable movies={data?.content || []} sort={sort} order={order} search={search} isLoading={isLoading} />
        <MoviePagination currentPage={page} totalPages={data?.totalPages || 1} />
      </Card>
    </div>
  )
}
