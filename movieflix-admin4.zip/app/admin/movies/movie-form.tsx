"use client"

import type React from "react"

import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { useRouter } from "next/navigation"
import { useState } from "react"
import { useCreateMovie, useUpdateMovie } from "@/lib/hooks/use-movies"
import Image from "next/image"
import { Loader2, Upload } from "lucide-react"

const movieSchema = z.object({
  id: z.string().optional(),
  title: z.string().min(1, "Title is required"),
  director: z.string().min(1, "Director is required"),
  studio: z.string().min(1, "Studio is required"),
  cast: z.string().min(1, "Cast is required"),
  releaseYear: z.coerce
    .number()
    .min(1900, "Year must be at least 1900")
    .max(new Date().getFullYear() + 5, "Year cannot be in the far future"),
  description: z.string().min(10, "Description must be at least 10 characters"),
})

type MovieFormValues = z.infer<typeof movieSchema>

interface MovieFormProps {
  movie?: MovieFormValues & { posterUrl?: string }
}

export function MovieForm({ movie }: MovieFormProps) {
  const router = useRouter()
  const [posterFile, setPosterFile] = useState<File | null>(null)
  const [posterPreview, setPosterPreview] = useState<string | null>(movie?.posterUrl || null)

  const createMovieMutation = useCreateMovie()
  const updateMovieMutation = useUpdateMovie()

  const isSubmitting = createMovieMutation.isPending || updateMovieMutation.isPending

  const form = useForm<MovieFormValues>({
    resolver: zodResolver(movieSchema),
    defaultValues: movie || {
      title: "",
      director: "",
      studio: "",
      cast: "",
      releaseYear: new Date().getFullYear(),
      description: "",
    },
  })

  const handlePosterChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]
    if (!file) return

    setPosterFile(file)

    // Create preview URL
    const reader = new FileReader()
    reader.onloadend = () => {
      setPosterPreview(reader.result as string)
    }
    reader.readAsDataURL(file)
  }

  const onSubmit = async (data: MovieFormValues) => {
    const formData = new FormData()

    // Add all form fields to FormData
    Object.entries(data).forEach(([key, value]) => {
      if (value !== undefined) {
        formData.append(key, value.toString())
      }
    })

    // Add poster file if selected
    if (posterFile) {
      formData.append("poster", posterFile)
    }

    if (movie?.id) {
      // Update existing movie
      updateMovieMutation.mutate(
        { id: movie.id, formData },
        {
          onSuccess: () => {
            router.push("/admin/movies")
          },
        },
      )
    } else {
      // Create new movie
      createMovieMutation.mutate(formData, {
        onSuccess: () => {
          router.push("/admin/movies")
        },
      })
    }
  }

  return (
    <Card>
      <CardContent className="pt-6">
        <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
            <div className="space-y-4">
              <div>
                <Label htmlFor="title">Title</Label>
                <Input id="title" {...form.register("title")} />
                {form.formState.errors.title && (
                  <p className="text-sm text-red-500 mt-1">{form.formState.errors.title.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="director">Director</Label>
                <Input id="director" {...form.register("director")} />
                {form.formState.errors.director && (
                  <p className="text-sm text-red-500 mt-1">{form.formState.errors.director.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="studio">Studio</Label>
                <Input id="studio" {...form.register("studio")} />
                {form.formState.errors.studio && (
                  <p className="text-sm text-red-500 mt-1">{form.formState.errors.studio.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="cast">Cast</Label>
                <Input id="cast" {...form.register("cast")} />
                {form.formState.errors.cast && (
                  <p className="text-sm text-red-500 mt-1">{form.formState.errors.cast.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="releaseYear">Release Year</Label>
                <Input id="releaseYear" type="number" {...form.register("releaseYear")} />
                {form.formState.errors.releaseYear && (
                  <p className="text-sm text-red-500 mt-1">{form.formState.errors.releaseYear.message}</p>
                )}
              </div>
            </div>

            <div className="space-y-4">
              <div>
                <Label htmlFor="description">Description</Label>
                <Textarea id="description" rows={5} {...form.register("description")} />
                {form.formState.errors.description && (
                  <p className="text-sm text-red-500 mt-1">{form.formState.errors.description.message}</p>
                )}
              </div>

              <div>
                <Label htmlFor="poster">Movie Poster</Label>
                <div className="mt-2 flex items-center gap-4">
                  {posterPreview ? (
                    <div className="relative h-40 w-28 overflow-hidden rounded border">
                      <Image
                        src={posterPreview || "/placeholder.svg"}
                        alt="Movie poster preview"
                        fill
                        className="object-cover"
                      />
                    </div>
                  ) : (
                    <div className="flex h-40 w-28 items-center justify-center rounded border border-dashed">
                      <span className="text-sm text-muted-foreground">No poster</span>
                    </div>
                  )}

                  <div className="flex-1">
                    <Label
                      htmlFor="poster-upload"
                      className="flex cursor-pointer items-center gap-2 rounded-md border px-4 py-2 hover:bg-muted"
                    >
                      <Upload className="h-4 w-4" />
                      <span>{posterFile ? posterFile.name : "Upload poster"}</span>
                      <Input
                        id="poster-upload"
                        type="file"
                        accept="image/*"
                        className="hidden"
                        onChange={handlePosterChange}
                      />
                    </Label>
                    <p className="mt-1 text-xs text-muted-foreground">Recommended size: 500x750px. Max size: 2MB.</p>
                  </div>
                </div>
              </div>
            </div>
          </div>

          <div className="flex justify-end gap-4">
            <Button
              type="button"
              variant="outline"
              onClick={() => router.push("/admin/movies")}
              disabled={isSubmitting}
            >
              Cancel
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting && <Loader2 className="mr-2 h-4 w-4 animate-spin" />}
              {movie?.id ? "Update Movie" : "Add Movie"}
            </Button>
          </div>
        </form>
      </CardContent>
    </Card>
  )
}
