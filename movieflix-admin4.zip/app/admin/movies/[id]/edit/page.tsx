"use client"

import { useParams, useRouter } from "next/navigation"
import { MovieForm } from "../../movie-form"
import { useMovie } from "@/lib/hooks/use-movies"
import { useToast } from "@/components/ui/use-toast"

export default function EditMoviePage() {
  const params = useParams()
  const router = useRouter()
  const { toast } = useToast()
  const id = params.id as string

  const { data: movie, isLoading, error } = useMovie(id)

  if (error) {
    toast({
      title: "Error",
      description: "Failed to load movie details",
      variant: "destructive",
    })
    router.push("/admin/movies")
    return null
  }

  if (isLoading) {
    return (
      <div className="flex h-[calc(100vh-200px)] items-center justify-center">
        <div className="h-8 w-8 animate-spin rounded-full border-4 border-primary border-t-transparent"></div>
      </div>
    )
  }

  if (!movie) {
    toast({
      title: "Error",
      description: "Movie not found",
      variant: "destructive",
    })
    router.push("/admin/movies")
    return null
  }

  return (
    <div>
      <h1 className="text-3xl font-bold mb-6">Edit Movie</h1>
      <MovieForm movie={movie} />
    </div>
  )
}
